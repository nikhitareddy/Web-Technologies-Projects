package firstapplication.example.com.hw9fbsearch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by nikhi on 22-04-2017.
 */

public class FavoritesEventFragment extends Fragment  {

    ListView list;

    public ArrayList<events> eventArray= new ArrayList<events>();
    public eventAdapter adapter;
    Map<String, Integer> mapIndex;
    public static final String MESSAGE = "firstapplication.example.com.hw9fbsearch";


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.fav_view, container, false);

        Gson gson = new Gson();
        // load favorites
        SharedPreferences prefs = getActivity().getSharedPreferences("Favorites", MODE_PRIVATE);
        String BillsFavoriteArrayString = prefs.getString("eventsFavoriteArrayString", null);
        if (BillsFavoriteArrayString != null) {
            eventArray = gson.fromJson(BillsFavoriteArrayString,
                    new TypeToken<ArrayList<events>>() {
                    }.getType());



        }


        list = (ListView) v.findViewById(R.id.list);





        adapter=new eventAdapter(getActivity(), eventArray);
        list.setAdapter(adapter);


        // displayIndex();


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // TODO Auto-generated method stub
                // String Slecteditem= names.get(position);
                String Slecteditem= eventArray.get(position).uid;
                Log.d("LagislatorsFragment","clicked.....");
                // Toast.makeText(getActivity().getApplicationContext(), Slecteditem, Toast.LENGTH_SHORT).show();
                Gson gson = new Gson();
                String LegislatorJson = gson.toJson(eventArray.get(position));
                Intent intent = new Intent(getActivity(), eventInfoActivity.class);
                intent.putExtra(MESSAGE, LegislatorJson);
                startActivity(intent);

            }
        });

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";



                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {








            }
        }.execute(null, null, null);


        return v;
    }



    @Override
    public void onResume() {
        super.onResume();
        // load favorites
        Gson gson = new Gson();
        SharedPreferences prefs = getActivity().getSharedPreferences("Favorites", MODE_PRIVATE);
        String BillsFavoriteArrayString = prefs.getString("eventsFavoriteArrayString", null);
        if (BillsFavoriteArrayString != null) {
            eventArray = gson.fromJson(BillsFavoriteArrayString,
                    new TypeToken<ArrayList<events>>() {
                    }.getType());



        }





        adapter=new eventAdapter(getActivity(), eventArray);
        list.setAdapter(adapter);


    }


}
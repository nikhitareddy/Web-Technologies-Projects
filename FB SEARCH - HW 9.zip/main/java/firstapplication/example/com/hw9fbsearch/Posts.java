package firstapplication.example.com.hw9fbsearch;

import java.security.PublicKey;

/**
 * Created by nikhi on 21-04-2017.
 */

public class Posts {
    public String msg;
    public String date;
    public String pic;
    public String na;
}

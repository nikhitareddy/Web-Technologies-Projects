package firstapplication.example.com.hw9fbsearch;

/**
 * Created by nikhi on 19-04-2017.
 */

public class album {
    public String nam;
    public String url;
    public String url2;

}

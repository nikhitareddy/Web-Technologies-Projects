package firstapplication.example.com.hw9fbsearch;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by nikhi on 20-04-2017.
 */

public class albumAdapter extends BaseAdapter {

    private final Context context;
    private LayoutInflater inflater;
    private ArrayList<album> objects;

    private class ViewHolder {

        TextView textView3;

    }

    public albumAdapter(Context context, ArrayList<album> objects) {
        inflater = LayoutInflater.from(context);
        this.objects = objects;
        this.context=context;
    }

    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }


    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        //Posts p=new Posts();
        albumAdapter.ViewHolder holder = null;
        if(convertView == null) {
            holder = new albumAdapter.ViewHolder();
            convertView = inflater.inflate(R.layout.album1_view, null);

            holder.textView3 = (TextView) convertView.findViewById(R.id.msg1);

            convertView.setTag(holder);
        } else {
            holder = (albumAdapter.ViewHolder) convertView.getTag();
        }

        holder.textView3.setText(objects.get(position).nam);

        // if(p.pic!=null) {

        //}
        return convertView;
    }
}
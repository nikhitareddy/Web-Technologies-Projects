package firstapplication.example.com.hw9fbsearch;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by nikhi on 19-04-2017.
 */

public class cntrlFragment extends Fragment {
    private FragmentTabHost mTabHost;
    private String qu;
    private static final String TAG = "MyActivity";



    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        Context context=getContext();
        View rootView = inflater.inflate(R.layout.fragment_3, container, false);


        String value = getArguments().getString("Key");
        Log.d("onCreateView: ",value);
        Bundle ub = new Bundle();
        ub.putString("bio", value);
       // user_fragment uf=new user_fragment();
        mTabHost = (FragmentTabHost) rootView.findViewById(android.R.id.tabhost);
        //mTabHost.setup(getActivity(), getChildFragmentManager(), R.id.fragment_committes_3);

        mTabHost.setup(getActivity(), getChildFragmentManager(), R.id.realtabcontent3);
        mTabHost.addTab(mTabHost.newTabSpec("user").setIndicator("Users", ContextCompat.getDrawable(context,R.drawable.user)),
                user_fragment.class,ub);
        mTabHost.addTab(mTabHost.newTabSpec("page").setIndicator("Pages"),
                pages_fragment.class, ub);
        mTabHost.addTab(mTabHost.newTabSpec("event").setIndicator("Event"),
                event_Fragment.class, ub);
        mTabHost.addTab(mTabHost.newTabSpec("group").setIndicator("Group"),
                group_Fragment.class, ub);
        mTabHost.addTab(mTabHost.newTabSpec("place").setIndicator("Place"),
                places_Fragment.class, ub);

        return rootView;


    }
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Facebook Search");




    }
}


package firstapplication.example.com.hw9fbsearch;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

import static firstapplication.example.com.hw9fbsearch.group_Fragment.MESSAGE;

/**
 * Created by nikhi on 27-04-2017.
 */

public class groupInfoActivity extends AppCompatActivity {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     *
     */
    private groupInfoActivity.SectionsPagerAdapter mSectionsPagerAdapter;


    /**private static final String TAG
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;
    private static String id="";
    public static String ur="";
    public static String na="";
    ArrayList<groups> groupFavoriteArray= new ArrayList<groups>();
    boolean starred=false;
    boolean star=false;
    CallbackManager callbackManager;
    ShareDialog shareDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);
        setContentView(R.layout.activity_group_info);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        String LegislatorString = bundle.getString(group_Fragment.MESSAGE);
        Log.d("group ",LegislatorString);
        groups pg=new groups();
        Gson gson = new Gson();
        final groups legislator = gson.fromJson(LegislatorString, groups.class);
        Log.d("id ",legislator.uid);
        id=legislator.uid;
        ur=legislator.web;
        na=legislator.nam;
       /* if(legislator.uid != null)
        {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://webassignments-env.us-west-2.elasticbeanstalk.com/webt.php?id="+legislator.uid));
            Log.d("id url: ",intent.toString());
            startActivity(intent);

        }*/
        // Intent intent = new Intent(Intent.ACTION_VIEW, legislator.uid);
        // startActivity(intent);
        //  Log.d("onCreate: ", legislator.toString());
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new groupInfoActivity.SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.albums);
        tabLayout.getTabAt(1).setIcon(R.drawable.posts);

        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        //Inflater inflater;
        //ViewGroup container;


        SharedPreferences prefs = getSharedPreferences("Favorites", MODE_PRIVATE);
        String LegislatorFavoriteArrayString = prefs.getString("groupFavoriteArrayString", null);
        if (LegislatorFavoriteArrayString != null) {
            groupFavoriteArray = gson.fromJson(LegislatorFavoriteArrayString,
                    new TypeToken<ArrayList<groups>>() {
                    }.getType());

            boolean contains=false;
            for(groups l: groupFavoriteArray){

                if(legislator.uid.equalsIgnoreCase(l.uid)){
                    contains=true;

                }

            }
            if(contains) {
                Uri path = Uri.parse("android.resource://firstapplication.example.com.hw9fbsearch/" + R.drawable.btn_star_big_on);
              //  pg.im=path.toString();
                Log.d("in shared: ","shared");
                starred = true;
                star=true;
            }

        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user_info, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        pages pg=new pages();

        //noinspection SimplifiableIfStatement
        if (id == R.id.favo) {


            Log.d("favo 1 ","favo favo");
            Bundle bundle = getIntent().getExtras();
            String LegislatorString = bundle.getString(MESSAGE);
            Gson gson = new Gson();
            final groups legislator = gson.fromJson(LegislatorString, groups.class);
            starred=!starred;
            if(starred){
                item.setTitle("Remove from Favorites");
                String message = "Added to favorites" ;
                Toast.makeText(groupInfoActivity.this,message,Toast.LENGTH_SHORT).show();
                Uri path = Uri.parse("android.resource://firstapplication.example.com.hw9fbsearch/" + R.drawable.btn_star_big_on);
                pg.im=path.toString();

                //Picasso.with(userInfoActivity.this).load(android.R.drawable.btn_star_big_on).into(favoriteImage);

                groupFavoriteArray.add(legislator);
                Log.d("Favorite array",legislator.toString());



            }
            else{
                // item.setTitle("Save to Favorites");
                if(!star){
                    item.setTitle("Remove save from Favorites");
                    String message = "Removed from favorites" ;
                    Log.d("onremove fav: ","##################################");
                    Toast.makeText(groupInfoActivity.this,message,Toast.LENGTH_SHORT).show();
                    Uri path = Uri.parse("android.resource://firstapplication.example.com.hw9fbsearch/" + R.drawable.favoff);
                    pg.im=path.toString();
                }
                else{
                    item.setTitle("Save to Favorites");
                    String message = "Removed from favorites" ;
                    Log.d("onremove fav: ","*************************");
                    Toast.makeText(groupInfoActivity.this,message,Toast.LENGTH_SHORT).show();
                    Uri path = Uri.parse("android.resource://firstapplication.example.com.hw9fbsearch/" + R.drawable.favoff);
                    pg.im=path.toString();

                }

                //  Picasso.with(LagislatoInfoActivity.this).load(android.R.drawable.btn_star_big_off).into(favoriteImage);
                int in=0;
                for(int i=0;i<groupFavoriteArray.size();i++){

                    if(legislator.uid.equalsIgnoreCase(groupFavoriteArray.get(i).uid)){
                        in=i;

                    }
                    Log.d("Favorite ese array",groupFavoriteArray.toString());

                }
                groupFavoriteArray.remove(in);

            }
            Gson gson1 = new Gson();
            // save new favorite list
            String ChangedLegislatorFavoriteArrayString = gson1.toJson(groupFavoriteArray);
            SharedPreferences.Editor editor = getSharedPreferences("Favorites", MODE_PRIVATE).edit();
            Log.d("onshared pref: ",editor.toString());
            editor.putString("groupFavoriteArrayString", ChangedLegislatorFavoriteArrayString);
            editor.commit();



            return true;
        }
        else if (id == R.id.share) {
            Bundle bundle = getIntent().getExtras();
            String LegislatorString = bundle.getString(group_Fragment.MESSAGE);
            Gson gson = new Gson();
            final groups legislator = gson.fromJson(LegislatorString, groups.class);
            Log.d("onOptionsItemSelected: ", "facebook");
            ShareLinkContent content = new ShareLinkContent.Builder()
                    .setContentUrl(Uri.parse("https://developers.facebook.com"))
                    .setImageUrl(Uri.parse(legislator.web))
                    .setContentTitle(legislator.nam)
                    .setContentDescription("FB Search fron USC CSCI 571")
                    .build();
            shareDialog.show(content);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // FragmentManager fragmentManager = getSupportFragmentManager();
            Bundle bundle = new Bundle();
            bundle.putString("id",id );
            switch(position){
                case 0:

                    ualb tab1=new ualb();
                    tab1.setArguments(bundle);
                    return tab1;
                case 1:
                    bundle.putString("url",ur);
                    bundle.putString("name",na);
                    upos tab2=new upos();
                    tab2.setArguments(bundle);
                    return tab2;
                default:
                    return null;



            }
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            //  return PlaceholderFragment.newInstance(position + 1);

        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Albums";
                case 1:
                    return "Posts";

            }
            return null;
        }
    }
}


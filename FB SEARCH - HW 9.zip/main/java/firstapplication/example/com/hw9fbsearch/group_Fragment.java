package firstapplication.example.com.hw9fbsearch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by nikhi on 19-04-2017.
 */

public class group_Fragment extends Fragment {
    private static final String TAG = "MyActivity";
    ListView list;
    Map<String, Integer> mapIndex;
    ArrayList<groups> groupArray= new ArrayList<groups>();
    public static final String MESSAGE = "firstapplication.example.com.hw9fbsearch";
    private Button btn_prev;
    private Button btn_next;
    private int pageCount ;
    private int increment = 0;
    public int TOTAL_LIST_ITEMS = 25;
    public int NUM_ITEMS_PAGE   = 10;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.frag_view, container, false);
        // View v1 = inflater.inflate(R.layout.home, container, false);
        //System.out.println("MyClass.getView() " );

        //  final EditText qw = (EditText) v1.findViewById(R.id.query);
        final String val = getArguments().getString("bio");
        // que w=new que();
        //Intent intent = getActivity().getIntent();
        // String message = getActivity().getIntent().getStringExtra(home_fragment.EXTRA_MESSAGE);
        //  Log.d("user view ", val);
        groupArray= new ArrayList<groups>();
        //Intent intent = getIntent();
        // String message=getActivity().getIntent().getExtras().getString(home_fragment.EXTRA_MESSAGE);
        // String message = intent.getStringExtra(home_fragment.EXTRA_MESSAGE);
        //  Log.d("Intent onCreateView: ",intent.getStringExtra(home_fragment.EXTRA_MESSAGE));

        list = (ListView) v.findViewById(R.id.list);
        btn_prev     = (Button) v.findViewById(R.id.prev);
        btn_next     = (Button) v.findViewById(R.id.next);
        btn_prev.setEnabled(false);
      /*  View v1 = inflater.inflate(R.layout.user_view, container, false);
        ImageView img=(ImageView) v1.findViewById(R.id.imageView7);
       img.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.d( "onClick: ", String.valueOf(v.getId()));
                //v.getId() will give you the image id
            }
        });*/
        //System.out.println("MyClass.getView() " );

        //users t=new users();
        // Log.d("string parse: ", t.q);

        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {

                String msg = "";
                try {


                    HttpGet httppost = new HttpGet("http://webassignments-env.us-west-2.elasticbeanstalk.com/webt.php?name="+val+"&type=group");
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = httpclient.execute(httppost);

                    // StatusLine stat = response.getStatusLine();
                    int status = response.getStatusLine().getStatusCode();
                    // Log.d("LagislatorsFragment",status.toString());
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        String data = EntityUtils.toString(entity);
                        //  Log.d("LagislatorsFragment",data);

                        //JSONObject jsono = new JSONObject(data);

                        msg=data;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

                // Log.d("user",msg);
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                // SharedPreferences preferences;
                // if (!TextUtils.isEmpty(msg)) {
                // Toast.makeText(getApplicationContext(), msg,
                // Toast.LENGTH_LONG).show();
                // }
                //msg = msg.substring(1, msg.length() - 1);
                //Log.d("LagislatorsFragment","Committee is: "+msg);
                try {
                    JSONObject jsonObj = new JSONObject(msg);
                    Log.d("json",jsonObj.toString());
                    JSONArray data = jsonObj.getJSONArray("data");
                    Log.d("data", data.toString());
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject c = data.getJSONObject(i);
                        // JSONObject c = data.getJSONObject(0);
                        // Log.d("c",c.toString());
                        groups p = new groups();
                        p.uid = c.getString("id");
                        p.nam=c.getString("name");
                        JSONObject pic = c.getJSONObject("picture");
                        JSONObject dat = pic.getJSONObject("data");
                        SharedPreferences shf = group_Fragment.this.getActivity().getSharedPreferences("Favorites", MODE_PRIVATE);
                        String strPref = shf.getString("groupFavoriteArrayString", null);

                        if(strPref != null) {
                            // do some thing
                            Uri path = Uri.parse("android.resource://firstapplication.example.com.hw9fbsearch/" + R.drawable.favoff);
                            //p.im=path.toString();

                        }
                        else{
                            Uri path = Uri.parse("android.resource://firstapplication.example.com.hw9fbsearch/" + R.drawable.btn_star_big_on);
                            //p.im=path.toString();
                        }

                        p.web=dat.getString("url");


                        // p.img.setImageDrawable(getResources().getDrawable(R.drawable.favoff));
                        groupArray.add(p);
                        //   Log.d("id",pageArray.toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                loadList(0);

                btn_next.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {



                        increment++;
                        loadList(increment);
                        CheckEnable();
                    }
                });

                btn_prev.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {

                        increment--;
                        loadList(increment);
                        CheckEnable();
                    }
                });

            }

            /**
             * Method for enabling and disabling Buttons
             */
            private void CheckEnable()
            {
                if(increment+1 == pageCount)
                {
                    btn_next.setEnabled(false);
                }
                else if(increment == 0)
                {
                    btn_prev.setEnabled(false);
                }
                else
                {
                    btn_prev.setEnabled(true);
                    btn_next.setEnabled(true);
                }
            }

            /**
             * Method for loading data in listview
             * @param number
             */
            private void loadList(int number)
            {
                final ArrayList<groups> sort = new ArrayList<groups>();


                int start = number * NUM_ITEMS_PAGE;
                for(int i=start;i<(start)+NUM_ITEMS_PAGE;i++)
                {
                    if(i<groupArray.size())
                    {
                        sort.add(groupArray.get(i));
                    }
                    else
                    {
                        break;
                    }
                }
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        // TODO Auto-generated method stub
                        // String Slecteditem= names.get(position);
                        String Slecteditem= groupArray.get(position).uid;
                        Log.d("LagislatorsFragment","clicked.....");
                        // Toast.makeText(getActivity().getApplicationContext(), Slecteditem, Toast.LENGTH_SHORT).show();
                        Gson gson = new Gson();
                        String userJson = gson.toJson(sort.get(position));
                        Intent intent = new Intent(getActivity(), groupInfoActivity.class);
                        intent.putExtra(MESSAGE, userJson);
                        //   Log.d("onItemClick: ",userJson);
                        startActivity(intent);

                    }
                });


                groupAdapter adapter=new groupAdapter(getActivity(), sort);
                list.setAdapter(adapter);


// Creating a button - Load More




            }
        }.execute(null, null, null);


        // do something
        // query.setText("");
        //System.out.println("MyClass.getView() — get item number " );
  /*  String myUrl = "http://cs-server.usc.edu:36937/webt.php?name=usc&type=user";

    //String to place our result in
    String result;

    //Instantiate new instance of our class
    HttpGetRequest getRequest = new HttpGetRequest();

    //Perform the doInBackground method, passing in our url
                try {
        result = getRequest.execute(myUrl).get();
        Log.d(TAG, "MyClass.getView() — get item number " + result);
    } catch (InterruptedException e) {
        e.printStackTrace();
    } catch (ExecutionException e) {
        e.printStackTrace();
    }*/




        return v;
    }
}


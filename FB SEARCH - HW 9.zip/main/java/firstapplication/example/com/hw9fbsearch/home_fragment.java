package firstapplication.example.com.hw9fbsearch;

import android.app.Fragment;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;


import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.concurrent.ExecutionException;

import static android.R.id.message;
import static android.provider.AlarmClock.EXTRA_MESSAGE;
import static firstapplication.example.com.hw9fbsearch.R.id.query;

/**
 * Created by nikhi on 18-04-2017.
 */

public class home_fragment extends android.support.v4.app.Fragment {
    private static final String TAG = "MyActivity";

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments

        super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.home, container, false);
        //System.out.println("MyClass.getView() " );
       final Intent intent = new Intent(home_fragment.this.getActivity(), user_fragment.class);

        final EditText qw = (EditText) v.findViewById(R.id.query);

      //  String q = qw.getText().toString();

       // u.q=q;
       /* Intent intent = new Intent(home_fragment.this.getActivity(), user_fragment.class);
        EditText editText = (EditText) v.findViewById(R.id.query);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);*/

        Button button = (Button) v.findViewById(R.id.search);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //Fragment fragment = null;
               // Fragment fragment = new cntrlFragment();
                //fragment = new cntrlFragment();

               // Fragment fragment;
                //fragment= new cntrlFragment();
               //intent.putExtra(EXTRA_MESSAGE, qw.getText().toString() );
                String message=qw.getText().toString();
                if (message != null && !message.equals("")) {

                    cntrlFragment ldf = new cntrlFragment();
                    Bundle args = new Bundle();
                    args.putString("Key", qw.getText().toString());
                    ldf.setArguments(args);


                    Log.d("edittext ", qw.getText().toString());
                    //startActivity(intent);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.content_frame
                                    , ldf)
                            .commit();

                }
                else {
                    Toast.makeText(getActivity(), "Please enter a valid keyword.", Toast.LENGTH_SHORT).show();
                }



            }
        });
        Button buttontwo = (Button) v.findViewById(R.id.clear);
        buttontwo.setOnClickListener(new Button.OnClickListener()

        {
            public void onClick(View v) {
                Log.d("hello","clicked. clear....");
                qw.setText("");




            }
        });
        return v;
    }


}

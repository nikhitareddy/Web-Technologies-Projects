package firstapplication.example.com.hw9fbsearch;

import android.media.Image;
import android.widget.ImageView;

/**
 * Created by nikhi on 19-04-2017.
 */

public class pages {
    public String nam;
    public String uid;
    public String web;
    public String q;
    public Image img;
    public String im;
}

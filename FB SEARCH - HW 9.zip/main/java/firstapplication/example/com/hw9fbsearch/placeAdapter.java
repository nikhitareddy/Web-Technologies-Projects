package firstapplication.example.com.hw9fbsearch;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by nikhi on 27-04-2017.
 */

public class placeAdapter extends ArrayAdapter {

    private final Activity context;
    private final ArrayList<places> itemname;


    public placeAdapter(Activity context, ArrayList<places> itemname) {
        super(context, R.layout.user_view, itemname);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.itemname=itemname;

    }




    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //LayoutInflater inflater = (LayoutInflater)
        //  context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

        //  View right = row.findViewById(R.id.imageView7);


        placeAdapter.HistoryHolder holder = null;

        if(convertView == null)
        {
            LayoutInflater inflater=context.getLayoutInflater();
            View row = inflater.inflate(R.layout.user_view, parent, false);
            // ImageView img=(ImageView) row.findViewById(imageView7);

            convertView=inflater.inflate(R.layout.user_view, null,true);
            // ImageView icono = (ImageView) convertView.findViewById(R.id.imageView7);
            // seteamos el icono correspondiente
            // icono.setImageResource(R.drawable.arrowdown);


            holder = new placeAdapter.HistoryHolder();
            holder.imageIcon = (ImageView)convertView.findViewById(R.id.icon);
            holder.textTitle = (TextView)convertView.findViewById(R.id.firstLine);
            // holder.imageIcon = (ImageView) convertView.findViewById(R.id.imageView7);

            convertView.setTag(holder);

        }
        else
        {
            holder = (placeAdapter.HistoryHolder)convertView.getTag();
        }


        holder.textTitle.setText(itemname.get(position).nam);
//        imageView.setImageResource(imgid[position]);
        //holder.textScore.setText("("+itemname.get(position).party+")"+itemname.get(position).state+" - District "+itemname.get(position).district);

//        History history = data[position];
//        holder.textScore.setText(history.score);
//        holder.textTitle.setText(history.gametype);
        Picasso.with(this.context).load(itemname.get(position).web).resize(60, 70).placeholder(R.drawable.ic_menu_gallery)
                .error(R.drawable.ic_menu_gallery).into(holder.imageIcon);






        return convertView;
    }

    static class HistoryHolder
    {
        ImageView imageIcon;
        TextView textTitle;

    }

}


package firstapplication.example.com.hw9fbsearch;

/**
 * Created by nikhi on 22-04-2017.
 */

public class places {
    public String nam;
    public String uid;
    public String web;
    public String q;
    public String img;
}

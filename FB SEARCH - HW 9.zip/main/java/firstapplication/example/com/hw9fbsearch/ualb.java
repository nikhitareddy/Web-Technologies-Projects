package firstapplication.example.com.hw9fbsearch;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.ListView;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by nikhi on 20-04-2017.
 */

public class ualb extends Fragment {
    ExpandableListView li;
    ArrayList<String> albumArray= new ArrayList<String>();
    ArrayList<album> albumArray1= new ArrayList<album>();
    HashMap<String, List<String>> childArray=new HashMap<String, List<String>>();
    public static final String MESSAGE = "firstapplication.example.com.hw9fbsearch";
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.ualb, container, false);
       final String idi = getArguments().getString("id");
        li = (ExpandableListView) v.findViewById(R.id.alist);
        //Log.d("album ",idi);
       // li.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            li.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
                int previousItem = -1;

                @Override
                public void onGroupExpand(int groupPosition) {
                    Log.d( "onGroupExpand: ","hello");
                   /* if (groupPosition != previousItem)
                        li.collapseGroup(previousItem);
                    previousItem = groupPosition;*/
                }
            });

        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {

                String msg = "";
                try {


                    HttpGet httppost = new HttpGet("http://webassignments-env.us-west-2.elasticbeanstalk.com/webt.php?id="+idi);
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = httpclient.execute(httppost);

                    // StatusLine stat = response.getStatusLine();
                    int status = response.getStatusLine().getStatusCode();
                    // Log.d("LagislatorsFragment",status.toString());
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        String data = EntityUtils.toString(entity);
                        //  Log.d("LagislatorsFragment",data);

                        //JSONObject jsono = new JSONObject(data);

                        msg=data;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

                Log.d("alb",msg);
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                // if (!TextUtils.isEmpty(msg)) {
                // Toast.makeText(getApplicationContext(), msg,
                // Toast.LENGTH_LONG).show();
                // }
                //msg = msg.substring(1, msg.length() - 1);
                //Log.d("LagislatorsFragment","Committee is: "+msg);
                try {
                    JSONObject jsonObj = new JSONObject(msg);
                    Log.d("jsonq",jsonObj.toString());
                    if (jsonObj.has("albums")) {


                        JSONObject pic = jsonObj.getJSONObject("albums");

                        // JSONArray da = jsonObj.getJSONArray("data");
                        JSONArray data = pic.getJSONArray("data");
                        Log.d("dataq", data.toString());
                        if(data.length()>0) {
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject c = data.getJSONObject(i);

                                // JSONObject c = data.getJSONObject(0);
                                // Log.d("c",c.toString());
                                //  album a = new album();
                                //  a. = c.getString("id");
                                // JSONObject n = c.getJSONObject("data");
                                String n = c.getString("name");
                                albumArray.add(n);
                                Log.d("alb name ", albumArray.get(i));
                                if (c.has("photos")) {

                                    //  Log.d("onPosttop: ",top.get);
                                    JSONObject photo = c.getJSONObject("photos");
                                    JSONArray dat = photo.getJSONArray("data");
                                    List<String> top = new ArrayList<String>();
                                    for (int j = 0; j < dat.length(); j++) {
                                        JSONObject d = dat.getJSONObject(j);

                                        String picid = d.getString("id");
                                        String url = "https://graph.facebook.com/v2.8/" + picid + "/picture?access_token=EAAEfWJ0Hb9sBAF5Aeucc1w86V0XZAoN4M5l3FSZAQ6PKmngwG0KWQkJJ3gsAEaeSV5FWtcZCPvL8z569X9kCBBmZACQ5bHimGxAD3muSjCuzcflkcVSfQAhYPh0UfeUfQfuVpfkDImY9ocP4TNkQ4ZCcZBOqf6ZBXgZD";
                                        top.add(url);
                                        //  Log.d("alb url ", top.get(j));
                                    }
                                    //  Log.d("top: ",top.toString());
                                    // Log.d("onalbum array: ",albumArray.get(i));
                                    childArray.put(albumArray.get(i), top);
                                    //  a.url=dat.getString("url");
                                    //albumArray.add(a);
                                    // Log.d("idiii", childArray.toString());

                                }
                            }
                        }




                    }
                    else{
                      //  album a=new album();
                       // a.nam="No Albums Found";
                        albumArray.add("No Albums Found");
                        List<String> top = new ArrayList<String>();
                        top.add("");
                        childArray.put(albumArray.get(0), top);

                       // albumAdapter adapter2=new albumAdapter(getActivity(), albumArray1);
                       // li.setAdapter(adapter2);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                albumAdapter1 adapter1=new albumAdapter1(getActivity(), albumArray,childArray);
                li.setAdapter(adapter1);




// Creating a button - Load More




            }
        }.execute(null, null, null);





        return v;
    }
}

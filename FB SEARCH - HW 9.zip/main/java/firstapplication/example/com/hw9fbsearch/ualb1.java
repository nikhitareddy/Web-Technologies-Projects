package firstapplication.example.com.hw9fbsearch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by nikhi on 27-04-2017.
 */

public class ualb1 extends Fragment {
    ExpandableListView li;
    ArrayList<String> albumArray= new ArrayList<String>();
    ArrayList<album> albumArray1= new ArrayList<album>();
    HashMap<String, List<String>> childArray=new HashMap<String, List<String>>();
    public static final String MESSAGE = "firstapplication.example.com.hw9fbsearch";
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.ualb, container, false);
        final String idi = getArguments().getString("id");
        li = (ExpandableListView) v.findViewById(R.id.alist);
        //Log.d("album ",idi);
        // li.setOnItemClickListener(new AdapterView.OnItemClickListener() {

        li.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previousItem = -1;

            @Override
            public void onGroupExpand(int groupPosition) {
                Log.d( "onGroupExpand: ","hello");
                   /* if (groupPosition != previousItem)
                        li.collapseGroup(previousItem);
                    previousItem = groupPosition;*/
            }
        });

        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {

                String msg = "";
                try {


                    HttpGet httppost = new HttpGet("http://webassignments-env.us-west-2.elasticbeanstalk.com/webt.php?id="+idi);
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = httpclient.execute(httppost);

                    // StatusLine stat = response.getStatusLine();
                    int status = response.getStatusLine().getStatusCode();
                    // Log.d("LagislatorsFragment",status.toString());
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        String data = EntityUtils.toString(entity);
                        //  Log.d("LagislatorsFragment",data);

                        //JSONObject jsono = new JSONObject(data);

                        msg=data;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

                Log.d("alb",msg);
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                // if (!TextUtils.isEmpty(msg)) {
                // Toast.makeText(getApplicationContext(), msg,
                // Toast.LENGTH_LONG).show();
                // }
                //msg = msg.substring(1, msg.length() - 1);
                //Log.d("LagislatorsFragment","Committee is: "+msg);


                        albumArray.add("No Albums Found");
                        List<String> top = new ArrayList<String>();
                        top.add("");
                        childArray.put(albumArray.get(0), top);

                        // albumAdapter adapter2=new albumAdapter(getActivity(), albumArray1);
                        // li.setAdapter(adapter2);


                albumAdapter1 adapter1=new albumAdapter1(getActivity(), albumArray,childArray);
                li.setAdapter(adapter1);




// Creating a button - Load More




            }
        }.execute(null, null, null);





        return v;
    }
}


package firstapplication.example.com.hw9fbsearch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static android.R.attr.format;

/**
 * Created by nikhi on 20-04-2017.
 */

public class upos extends Fragment {
    ListView li;
    ArrayList<Posts> postArray= new ArrayList<Posts>();
   //HashMap<String, String> postArray=new HashMap<String, String>();
    public static final String MESSAGE = "firstapplication.example.com.hw9fbsearch";
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.upos, container, false);
        final String idi = getArguments().getString("id");
        final String url= getArguments().getString("url");
        final String nam= getArguments().getString("name");
        li = (ListView) v.findViewById(R.id.plist);
        //Log.d("album ",idi);
        // li.setOnItemClickListener(new AdapterView.OnItemClickListener() {



        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {

                String msg = "";
                try {


                    HttpGet httppost = new HttpGet("http://webassignments-env.us-west-2.elasticbeanstalk.com/webt.php?id="+idi);
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = httpclient.execute(httppost);

                    // StatusLine stat = response.getStatusLine();
                    int status = response.getStatusLine().getStatusCode();
                    // Log.d("LagislatorsFragment",status.toString());
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        String data = EntityUtils.toString(entity);
                        //  Log.d("LagislatorsFragment",data);

                        //JSONObject jsono = new JSONObject(data);

                        msg=data;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

                Log.d("post",msg);
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                // if (!TextUtils.isEmpty(msg)) {
                // Toast.makeText(getApplicationContext(), msg,
                // Toast.LENGTH_LONG).show();
                // }
                //msg = msg.substring(1, msg.length() - 1);
                //Log.d("LagislatorsFragment","Committee is: "+msg);
                try {
                    JSONObject jsonObj = new JSONObject(msg);
                    Log.d("jsonp",jsonObj.toString());
                    if(jsonObj.has("posts")) {
                        Log.d( "onPostExecute: ","posts ifff");
                        JSONObject pic = jsonObj.getJSONObject("posts");

                        // JSONArray da = jsonObj.getJSONArray("data");
                        JSONArray data = pic.getJSONArray("data");
                        Log.d("datap", data.toString());
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject c = data.getJSONObject(i);
                            // JSONObject c = data.getJSONObject(0);
                            // Log.d("c",c.toString());
                            Posts l = new Posts();
                            l.msg = c.getString("message");
                            l.date = c.getString("created_time");


                            l.pic = url;
                            l.na = nam;
                            // Log.d("posts name",l.na);
                            // Log.d("posts time",l.date);
                            //  Log.d("posts msg",l.msg);

                            // Log.d("posts url",l.pic);
                            postArray.add(l);
                            //  Log.d("posts",postArray.toString());
                        }
                        postAdapter adapter1=new postAdapter(getActivity(), postArray);
                        li.setAdapter(adapter1);
                    }
                    else {
                        Log.d("onPostExecute: ","say hii");
                        Posts l = new Posts();
                        l.msg = "No Posts Found";


                        postArray.add(l);
                        postAdapter1 adapter2=new postAdapter1(getActivity(), postArray);
                        li.setAdapter(adapter2);



                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }






// Creating a button - Load More




            }
        }.execute(null, null, null);





        return v;
    }
}


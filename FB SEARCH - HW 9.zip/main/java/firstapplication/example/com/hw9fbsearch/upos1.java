package firstapplication.example.com.hw9fbsearch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by nikhi on 27-04-2017.
 */

public class upos1 extends Fragment {
    ListView li;
    ArrayList<Posts> postArray= new ArrayList<Posts>();
    //HashMap<String, String> postArray=new HashMap<String, String>();
    public static final String MESSAGE = "firstapplication.example.com.hw9fbsearch";
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.upos, container, false);
        final String idi = getArguments().getString("id");
        final String url= getArguments().getString("url");
        final String nam= getArguments().getString("name");
        li = (ListView) v.findViewById(R.id.plist);
        //Log.d("album ",idi);
        // li.setOnItemClickListener(new AdapterView.OnItemClickListener() {



        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {

                String msg = "";
                try {


                    HttpGet httppost = new HttpGet("http://webassignments-env.us-west-2.elasticbeanstalk.com/webt.php?id="+idi);
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = httpclient.execute(httppost);

                    // StatusLine stat = response.getStatusLine();
                    int status = response.getStatusLine().getStatusCode();
                    // Log.d("LagislatorsFragment",status.toString());
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        String data = EntityUtils.toString(entity);
                        //  Log.d("LagislatorsFragment",data);

                        //JSONObject jsono = new JSONObject(data);

                        msg=data;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

                Log.d("post",msg);
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                // if (!TextUtils.isEmpty(msg)) {
                // Toast.makeText(getApplicationContext(), msg,
                // Toast.LENGTH_LONG).show();
                // }
                //msg = msg.substring(1, msg.length() - 1);
                //Log.d("LagislatorsFragment","Committee is: "+msg);
                Log.d("onPostExecute: ","msg1111");


                        Log.d("onPostExecute: ","say hii");
                        Posts l = new Posts();
                        l.msg = "No Posts Found";


                        postArray.add(l);
                        postAdapter1 adapter2=new postAdapter1(getActivity(), postArray);
                        li.setAdapter(adapter2);












// Creating a button - Load More




            }
        }.execute(null, null, null);





        return v;
    }
}



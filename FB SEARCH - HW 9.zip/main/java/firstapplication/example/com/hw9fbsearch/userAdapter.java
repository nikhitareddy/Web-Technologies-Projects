package firstapplication.example.com.hw9fbsearch;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import static android.R.attr.data;
import static firstapplication.example.com.hw9fbsearch.R.id.container;
import static firstapplication.example.com.hw9fbsearch.R.id.imageView7;

/**
 * Created by nikhi on 19-04-2017.
 */

public class userAdapter extends ArrayAdapter {

    private final Activity context;
    private final ArrayList<users> itemname;


    public userAdapter(Activity context, ArrayList<users> itemname) {
        super(context, R.layout.user_view, itemname);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.itemname=itemname;

    }




    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //LayoutInflater inflater = (LayoutInflater)
              //  context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

      //  View right = row.findViewById(R.id.imageView7);


        HistoryHolder holder = null;

        if(convertView == null)
        {
            LayoutInflater inflater=context.getLayoutInflater();
            View row = inflater.inflate(R.layout.user_view, parent, false);
           // ImageView img=(ImageView) row.findViewById(imageView7);

            convertView=inflater.inflate(R.layout.user_view, null,true);
           // ImageView icono = (ImageView) convertView.findViewById(R.id.imageView7);
            // seteamos el icono correspondiente
           // icono.setImageResource(R.drawable.arrowdown);


            holder = new HistoryHolder();
            holder.imageIcon = (ImageView)convertView.findViewById(R.id.icon);
            holder.textTitle = (TextView)convertView.findViewById(R.id.firstLine);
           // holder.imageIcon = (ImageView) convertView.findViewById(R.id.imageView7);

            convertView.setTag(holder);

        }
        else
        {
            holder = (HistoryHolder)convertView.getTag();
        }


        holder.textTitle.setText(itemname.get(position).nam);
//        imageView.setImageResource(imgid[position]);
        //holder.textScore.setText("("+itemname.get(position).party+")"+itemname.get(position).state+" - District "+itemname.get(position).district);

//        History history = data[position];
//        holder.textScore.setText(history.score);
//        holder.textTitle.setText(history.gametype);
        Picasso.with(this.context).load(itemname.get(position).web).resize(60, 70).placeholder(R.drawable.ic_menu_gallery)
                .error(R.drawable.ic_menu_gallery).into(holder.imageIcon);






        return convertView;
    }

    static class HistoryHolder
    {
        ImageView imageIcon;
        TextView textTitle;

    }

}
